--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE group_1;
--
-- Name: group_1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE group_1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE group_1 OWNER TO postgres;

\connect group_1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    country_key integer NOT NULL,
    name character varying(255),
    region character varying(255),
    continent character varying(255),
    currency character varying(255),
    capital character varying(255),
    total_population integer,
    birth_rate double precision,
    gross_national_income double precision,
    life_expectancy_at_birth double precision,
    labor_force_total integer,
    human_capital_index integer,
    population_grown_annual double precision
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: education; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education (
    education_key integer NOT NULL,
    total_literacy_rate double precision,
    male_literacy_rate double precision,
    female_literacy_rate double precision,
    primary_school_enrollment double precision,
    secondary_school_enrollment double precision,
    post_secondary_school_enrollment double precision,
    public_education_spending double precision,
    pop_compuslory_school_age_total integer,
    pop_offical_entrance_age_primary_total integer,
    pop_offical_entrance_age_secondary_total integer,
    teachers_primary_total integer,
    teachers_secondary_total integer
);


ALTER TABLE public.education OWNER TO postgres;

--
-- Name: event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event (
    event_key integer NOT NULL,
    name character varying(255),
    disaster_type character varying(255),
    start_day integer,
    end_day integer,
    start_month integer,
    end_month integer,
    start_year integer,
    end_year integer,
    disaster_subgroup character varying(255),
    total_deaths integer,
    no_injured integer,
    no_affected integer
);


ALTER TABLE public.event OWNER TO postgres;

--
-- Name: fact_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_table (
    month_key integer,
    country_key integer,
    education_key integer,
    population_key integer,
    quality_of_life_key integer,
    health_key integer,
    event_key integer,
    quality_of_life integer,
    development_index integer,
    human_development_index integer
);


ALTER TABLE public.fact_table OWNER TO postgres;

--
-- Name: health; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health (
    health_key integer NOT NULL,
    domestic_general_government_health_expenditure double precision,
    hospital_beds double precision,
    immunization_hepb3 double precision,
    immunization_dpt double precision,
    immunization_measles double precision,
    immunization_pol3 double precision,
    number_of_surgical_procedures double precision,
    number_of_infant_deaths double precision,
    number_of_stillbirths double precision,
    number_of_deaths_ages_20_24 double precision,
    physicians_per_1000 double precision,
    prevalence_of_overweight double precision,
    diabetes_prevalence double precision,
    prevalence_of_hiv_total double precision,
    adults_living_with_hiv double precision,
    adults_newly_infected_with_hiv double precision,
    children_living_with_hiv double precision,
    children_newly_infected_with_hiv double precision
);


ALTER TABLE public.health OWNER TO postgres;

--
-- Name: month; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.month (
    month_key integer NOT NULL,
    name character varying(255),
    month integer,
    quarter integer,
    year integer,
    decade integer
);


ALTER TABLE public.month OWNER TO postgres;

--
-- Name: population; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.population (
    population_key integer NOT NULL,
    life_expectancy_at_birth_f double precision,
    life_expectancy_at_birth_m double precision,
    life_expectancy_at_birth_t double precision,
    net_migration integer,
    population_ages_0_14 integer,
    population_ages_15_19 integer,
    population_ages_20_24 integer,
    population_ages_24_29 integer,
    population_ages_30_34 integer,
    population_ages_35_39 integer,
    population_ages_40_44 integer,
    population_ages_45_49 integer,
    population_ages_50_54 integer,
    population_ages_55_59 integer,
    population_ages_60_64 integer,
    population_ages_65_up integer,
    rural_population double precision,
    rural_population_growth_rate double precision,
    rural_poverty_rate double precision,
    urban_population double precision,
    urban_population_growth_rate double precision,
    urban_poverty_rate double precision
);


ALTER TABLE public.population OWNER TO postgres;

--
-- Name: quality_of_life; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quality_of_life (
    quality_of_life_key integer NOT NULL,
    access_to_drinking_water double precision,
    access_to_sanitation double precision,
    access_to_basic_handwashing_facilities double precision,
    unemployment_rate_f double precision,
    unemployment_rate_m double precision,
    unemployment_rate_t double precision,
    maternal_leave_benefits double precision,
    access_to_electricity_total double precision,
    access_to_electricity_urban double precision,
    access_to_electricity_rural double precision,
    part_time_employment_t double precision,
    part_time_employment_f double precision,
    part_time_employment_m double precision
);


ALTER TABLE public.quality_of_life OWNER TO postgres;

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (country_key, name, region, continent, currency, capital, total_population, birth_rate, gross_national_income, life_expectancy_at_birth, labor_force_total, human_capital_index, population_grown_annual) FROM stdin;
\.
COPY public.country (country_key, name, region, continent, currency, capital, total_population, birth_rate, gross_national_income, life_expectancy_at_birth, labor_force_total, human_capital_index, population_grown_annual) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: education; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.education (education_key, total_literacy_rate, male_literacy_rate, female_literacy_rate, primary_school_enrollment, secondary_school_enrollment, post_secondary_school_enrollment, public_education_spending, pop_compuslory_school_age_total, pop_offical_entrance_age_primary_total, pop_offical_entrance_age_secondary_total, teachers_primary_total, teachers_secondary_total) FROM stdin;
\.
COPY public.education (education_key, total_literacy_rate, male_literacy_rate, female_literacy_rate, primary_school_enrollment, secondary_school_enrollment, post_secondary_school_enrollment, public_education_spending, pop_compuslory_school_age_total, pop_offical_entrance_age_primary_total, pop_offical_entrance_age_secondary_total, teachers_primary_total, teachers_secondary_total) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event (event_key, name, disaster_type, start_day, end_day, start_month, end_month, start_year, end_year, disaster_subgroup, total_deaths, no_injured, no_affected) FROM stdin;
\.
COPY public.event (event_key, name, disaster_type, start_day, end_day, start_month, end_month, start_year, end_year, disaster_subgroup, total_deaths, no_injured, no_affected) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: fact_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_table (month_key, country_key, education_key, population_key, quality_of_life_key, health_key, event_key, quality_of_life, development_index, human_development_index) FROM stdin;
\.
COPY public.fact_table (month_key, country_key, education_key, population_key, quality_of_life_key, health_key, event_key, quality_of_life, development_index, human_development_index) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: health; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health (health_key, domestic_general_government_health_expenditure, hospital_beds, immunization_hepb3, immunization_dpt, immunization_measles, immunization_pol3, number_of_surgical_procedures, number_of_infant_deaths, number_of_stillbirths, number_of_deaths_ages_20_24, physicians_per_1000, prevalence_of_overweight, diabetes_prevalence, prevalence_of_hiv_total, adults_living_with_hiv, adults_newly_infected_with_hiv, children_living_with_hiv, children_newly_infected_with_hiv) FROM stdin;
\.
COPY public.health (health_key, domestic_general_government_health_expenditure, hospital_beds, immunization_hepb3, immunization_dpt, immunization_measles, immunization_pol3, number_of_surgical_procedures, number_of_infant_deaths, number_of_stillbirths, number_of_deaths_ages_20_24, physicians_per_1000, prevalence_of_overweight, diabetes_prevalence, prevalence_of_hiv_total, adults_living_with_hiv, adults_newly_infected_with_hiv, children_living_with_hiv, children_newly_infected_with_hiv) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: month; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.month (month_key, name, month, quarter, year, decade) FROM stdin;
\.
COPY public.month (month_key, name, month, quarter, year, decade) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: population; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.population (population_key, life_expectancy_at_birth_f, life_expectancy_at_birth_m, life_expectancy_at_birth_t, net_migration, population_ages_0_14, population_ages_15_19, population_ages_20_24, population_ages_24_29, population_ages_30_34, population_ages_35_39, population_ages_40_44, population_ages_45_49, population_ages_50_54, population_ages_55_59, population_ages_60_64, population_ages_65_up, rural_population, rural_population_growth_rate, rural_poverty_rate, urban_population, urban_population_growth_rate, urban_poverty_rate) FROM stdin;
\.
COPY public.population (population_key, life_expectancy_at_birth_f, life_expectancy_at_birth_m, life_expectancy_at_birth_t, net_migration, population_ages_0_14, population_ages_15_19, population_ages_20_24, population_ages_24_29, population_ages_30_34, population_ages_35_39, population_ages_40_44, population_ages_45_49, population_ages_50_54, population_ages_55_59, population_ages_60_64, population_ages_65_up, rural_population, rural_population_growth_rate, rural_poverty_rate, urban_population, urban_population_growth_rate, urban_poverty_rate) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: quality_of_life; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quality_of_life (quality_of_life_key, access_to_drinking_water, access_to_sanitation, access_to_basic_handwashing_facilities, unemployment_rate_f, unemployment_rate_m, unemployment_rate_t, maternal_leave_benefits, access_to_electricity_total, access_to_electricity_urban, access_to_electricity_rural, part_time_employment_t, part_time_employment_f, part_time_employment_m) FROM stdin;
\.
COPY public.quality_of_life (quality_of_life_key, access_to_drinking_water, access_to_sanitation, access_to_basic_handwashing_facilities, unemployment_rate_f, unemployment_rate_m, unemployment_rate_t, maternal_leave_benefits, access_to_electricity_total, access_to_electricity_urban, access_to_electricity_rural, part_time_employment_t, part_time_employment_f, part_time_employment_m) FROM '$$PATH$$/3355.dat';

--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (country_key);


--
-- Name: education education_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_pkey PRIMARY KEY (education_key);


--
-- Name: event event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_pkey PRIMARY KEY (event_key);


--
-- Name: health health_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health
    ADD CONSTRAINT health_pkey PRIMARY KEY (health_key);


--
-- Name: month month_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.month
    ADD CONSTRAINT month_pkey PRIMARY KEY (month_key);


--
-- Name: population population_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.population
    ADD CONSTRAINT population_pkey PRIMARY KEY (population_key);


--
-- Name: quality_of_life quality_of_life_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quality_of_life
    ADD CONSTRAINT quality_of_life_pkey PRIMARY KEY (quality_of_life_key);


--
-- Name: fact_table fk_country; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_country FOREIGN KEY (country_key) REFERENCES public.country(country_key);


--
-- Name: fact_table fk_education; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_education FOREIGN KEY (education_key) REFERENCES public.education(education_key);


--
-- Name: fact_table fk_event; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_event FOREIGN KEY (event_key) REFERENCES public.event(event_key);


--
-- Name: fact_table fk_health; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_health FOREIGN KEY (health_key) REFERENCES public.health(health_key);


--
-- Name: fact_table fk_month; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_month FOREIGN KEY (month_key) REFERENCES public.month(month_key);


--
-- Name: fact_table fk_population; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_population FOREIGN KEY (population_key) REFERENCES public.population(population_key);


--
-- Name: fact_table fk_quality_of_life; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_table
    ADD CONSTRAINT fk_quality_of_life FOREIGN KEY (quality_of_life_key) REFERENCES public.quality_of_life(quality_of_life_key);


--
-- PostgreSQL database dump complete
--

